package com.example.chatspammer;
import java.awt.event.*;
import java.io.File;
import java.awt.*;
import javax.swing.*;

public class ChatOption {
	public static boolean isGUI;
	public static File file;
}
